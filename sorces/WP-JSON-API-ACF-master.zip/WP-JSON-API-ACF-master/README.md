WP-JSON-API-ACF
===============

By default the Wordpress JSON API: [WP-API](http://wp-api.org/) doesn't include Advanced Custom Fields.
This plugin fixes that. 

Grown from https://gist.github.com/rileypaulsen/9b4505cdd0ac88d5ef51 
but a plugin is nicer: I didn't want to modify the other plugin
 
